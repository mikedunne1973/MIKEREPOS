function doItNow(xmlFile, path, resultElementId){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			showResult(xhttp.responseXML);
		}
	};
	xhttp.open("GET", xmlFile, true);
	xhttp.send(); 

	function showResult(xml) {
		var txt = "";
		if (xml.evaluate) {
			var nodes = xml.evaluate(path, xml, null, XPathResult.ANY_TYPE, null);
			var result = nodes.iterateNext();
			while (result) {
				txt += result.childNodes[0].nodeValue + "<br>";
				result = nodes.iterateNext();
			} 
		// Code For Internet Explorer
		} else if (window.ActiveXObject || xhttp.responseType == "msxml-document") {
			xml.setProperty("SelectionLanguage", "XPath");
			nodes = xml.selectNodes(path);
			for (i = 0; i < nodes.length; i++) {
				txt += nodes[i].childNodes[0].nodeValue + "<br>";
			}
		}
		document.getElementById(resultElementId).innerHTML = txt;
	}
}

// ===============================================================================

function doItNow1() {
	var path = document.getElementById("which1").value;
	doItNow("movies.xml", path, "score1");
}
function doItNow2() {
	var path = document.getElementById("which2").value;
	doItNow("movies.xml", path, "score2");
}
function doItNow3() {
	var path = document.getElementById("which3").value;
	doItNow("movies.xml", path, "score3");
}
function doItNow4() {
	var path = "movies/moviestats[genre='Comedy']/filmtitle|movies/moviestats[genre='Comedy']/actor|movies/moviestats[genre='Comedy']/cost|movies/moviestats[genre='Comedy']/actress";
	doItNow("movies.xml", path, "score4");
}    
function doItNow5() {
	var path = "movies/moviestats[genre='Drama']/filmtitle|movies/moviestats[genre='Drama']/actor|movies/moviestats[genre='Drama']/cost|movies/moviestats[genre='Drama']/actress";
	doItNow("movies.xml", path, "score5");
}
function doItNow6() {
	var path = "movies/moviestats[genre='Action']/filmtitle|movies/moviestats[genre='Action']/actor|movies/moviestats[genre='Action']/cost|movies/moviestats[genre='Action']/actress";
	doItNow("movies.xml", path, "score6");
}

function doItNow7() {
	var path = "movies/moviestats[genre='Fantasy']/filmtitle|movies/moviestats[genre='Fantasy']/actor|movies/moviestats[genre='Fantasy']/cost|movies/moviestats[genre='Fantasy']/actress";
	doItNow("movies.xml", path, "score7");
}

