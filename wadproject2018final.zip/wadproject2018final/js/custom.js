var x, text1, text2, text3, text4, text5, text6, text7, text8, text9, y, z, zz, a, aa;

    
function sampleForm() {


// Code to verify the name is not empty 

  
    x = document.getElementById("fname").value; // this gets the value of the input field
   if (x == "") {
      text1 = "Name Can Not Be Blank";
	  document.getElementById("alert1").innerHTML = text1;
    }
	
	else if (/\s+/.test(x)) { 
	text2 = "That is a Real Name";
	alert(text2.toString());
	}
	
// code to validate email
	
	y = document.getElementById("email").value;
	yy = /@/.test(y);
	if (yy == false){
	text3 = "That is Not a Real Email";
	alert(text3.toString());
	}
	
	else if  (yy == true){
	text4 = "That is  a Real Email";
	document.getElementById("alert2").innerHTML = text4;
	}

// code to validate password
	
	z = document.getElementById("password").value;
	zz = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/.test(z);
	if (zz == false){
	text5 = "Your password must be: Minimum eight characters, at least one letter and one number";
    alert(text5.toString());    
	document.getElementById("alert3").innerHTML = text5;
	}
	
//	else if  (zz == true){
//	text3 = "That is  a Real Email";
//	alert("Password Contains a Number");
//	}
    
    // Code to check for human
    a = document.getElementById("robo").value;
	aa = /9/.test(a);
	if  (aa == true){
	text6 = "Thank you, sorry for doubting you! :)";
	document.getElementById("alert4").innerHTML = text6;
	}
    else if (aa == false){
	text7 = "That is Not the correct answer";
	alert(text7.toString());
    }
	
	
    // code to validate message
	
      x = document.getElementById("comment").value; // this gets the value of the input field
   if (x == "") {
      text8 = "Name Can Not Be Blank";
	  document.getElementById("alert5").innerHTML = text8;
    }
	
	else if (/^\S*$/.test(x)) { 
	text9 = "That is not a Real Message. Words must have spaces.  Please try again";
	alert(text9.toString());
	}
	
	
//	else if  (zz == true){
//	text3 = "That is  a Real Email";
//	alert("Password Contains a Number");
//	}
	
	

	
	//else if (zz == true){
	//text4 = "You are a Robot";
	//alert(text4.toString());
	//}
    
	


    
    }